package com.example.bookstoreapi.model;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


import javax.persistence.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Schema(description = "Details about a book")
public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Schema(description = "Unique identifier of the book")
    private Long id;
    @Version
    private Integer version;

    @Schema(description = "Title of the book")
    private String title;
    @Schema(description = "Author of the book")
    private String author;
    @Schema(description = "Price of the book")
    private double price;
    private String isbn;
}
