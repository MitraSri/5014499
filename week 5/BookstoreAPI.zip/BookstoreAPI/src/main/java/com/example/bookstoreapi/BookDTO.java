package com.example.bookstoreapi;

import org.springframework.hateoas.RepresentationModel;
import org.springframework.hateoas.server.mvc.WebMvcLinkBuilder;

public class BookDTO extends RepresentationModel<BookDTO> {
    private Long id;
    private String title;
    private String author;
    private Double price;
    private String isbn;

    // Getters and Setters

    public void addSelfLink() {
        this.add(WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(BookController.class).getBookById(this.id)).withSelfRel());
    }
    public void addRelatedLinks() {
        this.add(WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(AuthorController.class).getAuthorById(this.authorId)).withRel("author"));
        this.add(WebMvcLinkBuilder.linkTo(WebMvcLinkBuilder.methodOn(BookController.class).getBooksByAuthor(this.author)).withRel("books-by-author"));
    }

}
