package com.example.bookstoreapi;

public class CustomerDTO {
    private Long id;

    @NotNull
    @Size(min = 1, max = 100)
    private String name;

    @NotNull
    @Email
    private String email;

    @NotNull
    @Size(min = 1, max = 200)
    private String address;

    // Getters and Setters
}
