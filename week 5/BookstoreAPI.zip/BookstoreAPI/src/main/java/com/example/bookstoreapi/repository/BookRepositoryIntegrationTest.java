package com.example.bookstoreapi.repository;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;

@DataJpaTest
@ActiveProfiles("test")
public class BookRepositoryIntegrationTest {

    @Autowired
    private BookRepository bookRepository;

    @Test
    public void testSaveBook() {
        Book book = new Book("Sample Book", "Author", 29.99);
        bookRepository.save(book);
        assertThat(bookRepository.findById(book.getId())).isNotEmpty();
    }

    // Add more tests for repository methods as needed
}
