package com.example.bookstoreapi.controller;

package com.example.bookstore.controller;

import com.example.bookstore.model.BookDTO;
import com.example.bookstore.service.BookService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@WebMvcTest(BookController.class)
public class BookControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private BookService bookService;

    private List<BookDTO> bookList;

    @BeforeEach
    void setUp() {
        bookList = Arrays.asList(
            new BookDTO(1L, "Effective Java", "Joshua Bloch", 45.99, "978-0134685991"),
            new BookDTO(2L, "Clean Code", "Robert C. Martin", 40.99, "978-0132350884")
        );
    }

    @Test
    void testGetAllBooks() throws Exception {
        when(bookService.getAllBooks()).thenReturn(bookList);

        mockMvc.perform(get("/api/books"))
            .andExpect(status().isOk())
            .andExpect(content().json("[{'id':1,'title':'Effective Java'}, {'id':2,'title':'Clean Code'}]"));
    }

    @Test
    void testGetBookById() throws Exception {
        when(bookService.getBookById(1L)).thenReturn(java.util.Optional.ofNullable(bookList.get(0)));

        mockMvc.perform(get("/api/books/1"))
            .andExpect(status().isOk())
            .andExpect(content().json("{'id':1,'title':'Effective Java'}"));
    }
    @Test
    void testCreateBook() throws Exception {
        BookDTO newBook = new BookDTO(null, "Design Patterns", "Erich Gamma", 50.99, "978-0201633610");
        BookDTO savedBook = new BookDTO(3L, "Design Patterns", "Erich Gamma", 50.99, "978-0201633610");

        when(bookService.saveBook(Mockito.any(BookDTO.class))).thenReturn(savedBook);

        mockMvc.perform(post("/api/books")
                .contentType("application/json")
                .content("{'title':'Design Patterns','author':'Erich Gamma','price':50.99,'isbn':'978-0201633610'}"))
            .andExpect(status().isCreated())
            .andExpect(content().json("{'id':3,'title':'Design Patterns'}"));
    }

}
