package org.springframework.data.jpa.repository;

public interface JpaRepository {

}
