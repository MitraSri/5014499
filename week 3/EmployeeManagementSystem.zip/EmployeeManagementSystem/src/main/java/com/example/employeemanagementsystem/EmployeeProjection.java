package com.example.employeemanagementsystem;

public interface EmployeeProjection {
    String getName();
    String getDepartmentName();
}
