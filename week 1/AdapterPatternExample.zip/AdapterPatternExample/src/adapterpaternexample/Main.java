package adapterpaternexample;


public class Main {
 public static void main(String[] args) {
    
     PayPalGateway payPalGateway = new PayPalGateway();
     PaymentProcessor payPalProcessor = new PayPalAdapter(payPalGateway);
     payPalProcessor.processPayment(100.0);


     RazorPayGateway razorPayGateway = new RazorPayGateway();
     PaymentProcessor razorPayProcessor = new RazorPayAdapter(razorPayGateway);
     razorPayProcessor.processPayment(200.0);
 }
}
