package adapterpaternexample;

public class PayPalGateway {
	    public void makePayment(double amount) {
	        System.out.println("Processing payment of Rupees " + amount + " through PayPal.");
	    }
}
