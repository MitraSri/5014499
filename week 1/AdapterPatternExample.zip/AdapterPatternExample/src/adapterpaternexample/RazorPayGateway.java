package adapterpaternexample;

public class RazorPayGateway {
	    public void pay(double amount) {
	        System.out.println("Processing payment of Rupees " + amount + " through RazorPay.");
	    }
	}

