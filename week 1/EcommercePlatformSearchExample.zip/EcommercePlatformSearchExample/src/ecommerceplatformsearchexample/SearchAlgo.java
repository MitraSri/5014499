package ecommerceplatformsearchexample;

import java.util.*;

public class SearchAlgo {
 public static Product linearSearch(List<Product> products, String productName) {
     for (Product product : products) {
         if (product.getProductName().equalsIgnoreCase(productName)) {
             return product;
         }
     }
     return null;
 }
     public static Product binarySearch(List<Product> products, String productName) {
         int left = 0;
         int right = products.size() - 1;
         while (left <= right) {
             int mid = left + (right - left) / 2;
             int result = productName.compareToIgnoreCase(products.get(mid).getProductName());
             if (result == 0) {
                 return products.get(mid);
             }
             if (result > 0) {
                 left = mid + 1;
             } else {
                 right = mid - 1;
             }
         }
         return null;
     }
 }


