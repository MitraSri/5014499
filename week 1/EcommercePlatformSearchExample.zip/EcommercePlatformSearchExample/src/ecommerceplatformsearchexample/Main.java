package ecommerceplatformsearchexample;

import java.util.*;
public class Main {
 public static void main(String[] args) {
     List<Product> products = new ArrayList<>();
     products.add(new Product("1", "Laptop", "Electronics"));
     products.add(new Product("2", "Smartphone", "Electronics"));
     products.add(new Product("3", "Coffee Maker", "Appliances"));
     products.add(new Product("4", "Blender", "Appliances"));
     products.add(new Product("5", "Headphones", "Electronics"));

     System.out.println("Linear Search:");
     Product product = SearchAlgo.linearSearch(products, "Blender");
     System.out.println(product != null ? product : "Product not found");

     Collections.sort(products, Comparator.comparing(Product::getProductName));
     System.out.println("\nBinary Search:");
     product = SearchAlgo.binarySearch(products, "Blender");
     System.out.println(product != null ? product : "Product not found");
 }
}
