package decoratorpatternexample;


public class Main {
 public static void main(String[] args) {
     
     Notifier emailNotifier = new EmailNotifier();
     emailNotifier.send("Hello via Email!");

    
     Notifier emailAndSmsNotifier = new SMSNotifierDecorator(new EmailNotifier());
     emailAndSmsNotifier.send("Hello via Email and SMS!");

     Notifier emailSmsAndSlackNotifier = new SlackNotifierDecorator(new SMSNotifierDecorator(new EmailNotifier()));
     emailSmsAndSlackNotifier.send("Hello via Email, SMS, and Slack!");
 }
}
