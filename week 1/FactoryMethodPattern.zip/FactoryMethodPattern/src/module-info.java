/**
 * 
 */
/**
 * 
 */
module FactoryMethodPattern {
}