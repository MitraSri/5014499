package factorymethodpatternexample;

public class TestDocumentFactory {
public static void main(String[] args)
{
	DocumentFactory wordFactory=new WordDocumentFactory();
	Document wordDoc=wordFactory.createDocument();
	wordDoc.open();
	wordDoc.save();
	wordDoc.close();
}
}
