package inventorymanagementsystem;

public class Main {
 public static void main(String[] args) {
     Inventory inventory = new Inventory();
     
     Product product1 = new Product("1", "Laptop", 15, 67000);
     Product product2 = new Product("2", "Mobile phone", 57, 35000);
     inventory.addProduct(product1);
     inventory.addProduct(product2);
     
     System.out.println("All Products:");
     inventory.displayAllProducts();

     product1.setQuantity(8);
     inventory.updateProduct(product1);
     System.out.println("\nAfter updating product 1:");
     inventory.displayAllProducts();

     inventory.deleteProduct("2");
     System.out.println("\nAfter deleting product 2:");
     inventory.displayAllProducts();

     System.out.println("\nGet product 1:");
     System.out.println(inventory.getProduct("1"));
 }
}

