package observerpatternexample;


public class Main {
 public static void main(String[] args) {
     StockMarket stockMarket = new StockMarket();

     Observer mobileApp1 = new MobileApp("Uber");
     Observer mobileApp2 = new MobileApp("Instagram");
     Observer webApp = new WebApp("Youtube");

     stockMarket.registerObserver(mobileApp1);
     stockMarket.registerObserver(mobileApp2);
     stockMarket.registerObserver(webApp);

     stockMarket.setStockPrice(100.0);
     System.out.println();

     stockMarket.setStockPrice(150.5);
     System.out.println();

     stockMarket.deregisterObserver(mobileApp2);
     stockMarket.setStockPrice(200.0);
 }
}
