package strategypatternexample;


public interface PaymentStrategy {
 void pay(double amount);
}
