package strategypatternexample;

//Main.java
public class Main {
 public static void main(String[] args) {
     PaymentContext context = new PaymentContext();

     
     PaymentStrategy creditCardPayment = new CreditCardPayment("6847839354882939", "Mitra Sri");
     context.setPaymentStrategy(creditCardPayment);
     context.pay(100.0);

    
     PaymentStrategy payPalPayment = new PayPalPayment("mitrasri566@gmail.com");
     context.setPaymentStrategy(payPalPayment);
     context.pay(200.0);
 }
}

