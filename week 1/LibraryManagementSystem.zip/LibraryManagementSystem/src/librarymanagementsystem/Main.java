package librarymanagementsystem;


public class Main {
 public static void main(String[] args) {
     Library library = new Library();

     library.addBook(new Book(1, "Harry Potter", "J.K Rowling"));
     library.addBook(new Book(2, "Geronimo Stilton", "Scholastic"));
     library.addBook(new Book(3, "It Ends With Us", "Colleen Hoover"));
     library.addBook(new Book(4, "Pride and Prejudice", "Jane Austen"));

     System.out.println("Linear Search Result:");
     Book foundBook = library.linearSearchByTitle("Harry Potter");
     if (foundBook != null) {
         System.out.println(foundBook);
     } else {
         System.out.println("Book not found.");
     }

     library.sortBooksByTitle();
     System.out.println("\nBinary Search Result:");
     foundBook = library.binarySearchByTitle("Pride and Prejudice");
     if (foundBook != null) {
         System.out.println(foundBook);
     } else {
         System.out.println("Book not found.");
     }
 }
}
