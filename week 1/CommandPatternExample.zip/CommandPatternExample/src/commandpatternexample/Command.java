package commandpatternexample;


public interface Command {
 void execute();
}
