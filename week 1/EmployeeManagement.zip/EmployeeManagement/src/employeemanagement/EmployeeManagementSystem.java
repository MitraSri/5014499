package employeemanagement;

public class EmployeeManagementSystem {
 private Employee[] employees;
 private int count;

 public EmployeeManagementSystem(int size) {
     employees = new Employee[size];
     count = 0;
 }

 public void addEmployee(Employee employee) {
     if (count < employees.length) {
         employees[count] = employee;
         count++;
     } else {
         System.out.println("Array is full");
     }
 }

 public Employee searchEmployeeById(int employeeId) {
     for (int i = 0; i < count; i++) {
         if (employees[i].getEmployeeId() == employeeId) {
             return employees[i];
         }
     }
     return null; 
 }

 public void traverseEmployees() {
     for (int i = 0; i < count; i++) {
         System.out.println(employees[i]);
     }
 }

 public void deleteEmployeeById(int employeeId) {
     for (int i = 0; i < count; i++) {
         if (employees[i].getEmployeeId() == employeeId) {
             for (int j = i; j < count - 1; j++) {
                 employees[j] = employees[j + 1];
             }
             employees[count - 1] = null;
             count--;
             System.out.println("Employee with ID " + employeeId + " deleted.");
             return;
         }
     }
     System.out.println("Employee with ID " + employeeId + " not found.");
 }
}
