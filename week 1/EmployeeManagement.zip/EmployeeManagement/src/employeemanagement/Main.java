package employeemanagement;

public class Main {
 public static void main(String[] args) {
     EmployeeManagementSystem ems = new EmployeeManagementSystem(5);
     ems.addEmployee(new Employee(1, "Mitra", "Manager", 70000));
     ems.addEmployee(new Employee(2, "Sabrina", "Developer", 60000));
     ems.addEmployee(new Employee(3, "Justin", "Designer", 55000));
     System.out.println("Employee List:");
     ems.traverseEmployees();
     System.out.println("\nSearching for Employee with ID 2:");
     Employee employee = ems.searchEmployeeById(2);
     if (employee != null) {
         System.out.println(employee);
     } else {
         System.out.println("Employee not found.");
     }
     System.out.println("\nDeleting Employee with ID 2:");
     ems.deleteEmployeeById(2);
     System.out.println("\nEmployee List after deletion:");
     ems.traverseEmployees();
 }
}
