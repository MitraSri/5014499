package proxypatternexample;


public interface Image {
 void display();
}

