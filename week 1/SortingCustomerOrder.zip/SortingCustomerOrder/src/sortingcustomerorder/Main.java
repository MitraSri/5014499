package sortingcustomerorder;

import java.util.*;
public class Main {
 public static void main(String[] args) {
     List<Order> orders = new ArrayList<>();
     orders.add(new Order("100", "Ananya", 250));
     orders.add(new Order("101", "Mitra", 150));
     orders.add(new Order("102", "Charu", 300));
     orders.add(new Order("103", "Miru", 200));
     orders.add(new Order("104", "Akash", 100));

     System.out.println("Bubble Sort:");
     BubbleSort.bubbleSort(orders);
     for (Order order : orders) {
         System.out.println(order);
     }

     orders.clear();
     orders.add(new Order("100", "Ananya", 250));
     orders.add(new Order("101", "Mitra", 150));
     orders.add(new Order("102", "Charu", 300));
     orders.add(new Order("103", "Miru", 200));
     orders.add(new Order("104", "Akash", 100));

     // Quick Sort
     System.out.println("\nQuick Sort:");
     QuickSort.quickSort(orders, 0, orders.size() - 1);
     for (Order order : orders) {
         System.out.println(order);
     }
 }
}
