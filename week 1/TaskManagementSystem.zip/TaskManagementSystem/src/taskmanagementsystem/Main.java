package taskmanagementsystem;

public class Main {
 public static void main(String[] args) {
     TaskLL taskList = new TaskLL();

     taskList.addTask(new Task(1, "DBMS", "In Progress"));
     taskList.addTask(new Task(2, "Java", "Not Started"));
     taskList.addTask(new Task(3, "Networking", "Completed"));

     System.out.println("Task List:");
     taskList.traverseTasks();

     System.out.println("\nSearching for Task with ID 2:");
     Task task = taskList.searchTaskById(2);
     if (task != null) {
         System.out.println(task);
     } else {
         System.out.println("Task not found.");
     }
     System.out.println("\nDeleting Task with ID 2:");
     taskList.deleteTaskById(2);
     System.out.println("\nTask List after deletion:");
     taskList.traverseTasks();
 }
}
